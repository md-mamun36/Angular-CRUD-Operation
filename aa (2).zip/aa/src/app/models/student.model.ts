export class Student {
    id: number;
    name: string;
    country: string;
    gender: string;
    department: string;
}